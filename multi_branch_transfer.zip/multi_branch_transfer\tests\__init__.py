# -*- coding: utf-8 -*-

from . import test_mbt_request
