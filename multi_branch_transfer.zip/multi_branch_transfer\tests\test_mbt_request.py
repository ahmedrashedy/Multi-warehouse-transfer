import logging

from odoo.exceptions import UserError
from odoo.tests import TransactionCase, tagged

_logger = logging.getLogger(__name__)


@tagged('post_install', '-at_install', 'multi_branch_transfer')
class TestMbtRequest(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.company = cls.env.company
        cls.Warehouse = cls.env['stock.warehouse']
        cls.Product = cls.env['product.product']
        cls.LotStock = cls.env['stock.location']
        cls.User = cls.env['res.users']
        cls.Category = cls.env['product.category']

        cls.Warehouse.search([]).write({
            'x_is_main_source': False,
            'x_is_transit': False,
        })

        cls.test_category = cls.Category.create({
            'name': 'MBT Test Category',
        })

        cls.wh_main = cls.Warehouse.search(
            [('company_id', '=', cls.company.id)], limit=1)
        cls.wh_main.write({'x_is_main_source': True})

        cls.wh_transit = cls.Warehouse.create({
            'name': 'TEST Trans',
            'code': 'TT',
            'company_id': cls.company.id,
            'x_is_transit': True,
        })

        cls.wh_branch = cls.Warehouse.create({
            'name': 'TEST Branch',
            'code': 'TB',
            'company_id': cls.company.id,
        })

        cls.product_a = cls.Product.create({
            'name': 'MBT Product A',
            'is_storable': True,
            'categ_id': cls.test_category.id,
        })
        cls.product_b = cls.Product.create({
            'name': 'MBT Product B',
            'is_storable': True,
            'categ_id': cls.test_category.id,
        })

        cls.user_mbt = cls.env.ref('base.user_admin')

    def _add_stock(self, product, warehouse, qty=100.0):
        self.env['stock.quant'].with_context(inventory_mode=True).create({
            'product_id': product.id,
            'location_id': warehouse.lot_stock_id.id,
            'quantity': qty,
        })

    def test_01_happy_path(self):
        self._add_stock(self.product_a, self.wh_main, 50.0)
        req = self.env['mbt.request'].create({
            'dest_warehouse_id': self.wh_branch.id,
            'line_ids': [(0, 0, {
                'product_id': self.product_a.id,
                'product_uom_qty': 5.0,
            })],
        })
        self.assertEqual(req.state, 'draft')
        req.action_confirm()
        self.assertTrue(req.name.startswith('MBT/'))
        self.assertTrue(req.first_picking_id)
        self.assertTrue(req.second_picking_id)
        self.assertEqual(req.first_picking_id.state, 'done')
        self.assertEqual(req.second_picking_id.state, 'done')
        self.assertEqual(req.state, 'done')

    def test_02_insufficient_stock_then_cron(self):
        req = self.env['mbt.request'].create({
            'dest_warehouse_id': self.wh_branch.id,
            'line_ids': [(0, 0, {
                'product_id': self.product_a.id,
                'product_uom_qty': 100.0,
            })],
        })
        req.action_confirm()
        self.assertEqual(req.state, 'in_progress')
        self._add_stock(self.product_a, self.wh_main, 200.0)
        self.env['mbt.request'].cron_reprocess()
        self.assertEqual(req.first_picking_id.state, 'done')
        self.assertEqual(req.second_picking_id.state, 'done')
        self.assertEqual(req.state, 'done')

    def test_03_cancel_from_draft(self):
        req = self.env['mbt.request'].create({
            'dest_warehouse_id': self.wh_branch.id,
            'line_ids': [(0, 0, {
                'product_id': self.product_a.id,
                'product_uom_qty': 1.0,
            })],
        })
        req.action_cancel()
        self.assertEqual(req.state, 'cancelled')

    def test_04_cancel_in_progress(self):
        self._add_stock(self.product_a, self.wh_main, 50.0)
        req = self.env['mbt.request'].create({
            'dest_warehouse_id': self.wh_branch.id,
            'line_ids': [(0, 0, {
                'product_id': self.product_a.id,
                'product_uom_qty': 5.0,
            })],
        })
        req.action_confirm()
        if req.state == 'done':
            self.assertTrue(req.first_picking_id)
            self.assertEqual(req.first_picking_id.state, 'done')
            with self.assertRaises(UserError):
                req.action_cancel()
        else:
            req.action_cancel()
            self.assertEqual(req.state, 'cancelled')

    def test_05_constraints(self):
        req = self.env['mbt.request'].create({
            'dest_warehouse_id': self.wh_branch.id,
        })
        with self.assertRaises(UserError):
            req.action_confirm()

        req_2 = self.env['mbt.request'].create({
            'line_ids': [(0, 0, {
                'product_id': self.product_a.id,
                'product_uom_qty': 1.0,
            })],
        })
        with self.assertRaises(UserError):
            req_2.action_confirm()

    def test_06_dest_can_be_any_warehouse(self):
        self._add_stock(self.product_a, self.wh_main, 50.0)
        for dest in (self.wh_main, self.wh_transit, self.wh_branch):
            req = self.env['mbt.request'].create({
                'dest_warehouse_id': dest.id,
                'company_id': self.company.id,
                'line_ids': [(0, 0, {
                    'product_id': self.product_a.id,
                    'product_uom_qty': 1.0,
                })],
            })
            self.assertEqual(req.dest_warehouse_id, dest)

    def test_07_sequence_unique(self):
        self._add_stock(self.product_a, self.wh_main, 10.0)
        r1 = self.env['mbt.request'].create({
            'dest_warehouse_id': self.wh_branch.id,
            'line_ids': [(0, 0, {
                'product_id': self.product_a.id,
                'product_uom_qty': 1.0,
            })],
        })
        r2 = self.env['mbt.request'].create({
            'dest_warehouse_id': self.wh_branch.id,
            'line_ids': [(0, 0, {
                'product_id': self.product_a.id,
                'product_uom_qty': 1.0,
            })],
        })
        r1.action_confirm()
        r2.action_confirm()
        self.assertNotEqual(r1.name, r2.name)
        self.assertNotEqual(r1.name, 'New')
        self.assertNotEqual(r2.name, 'New')

    def test_08_unlink_blocked_in_progress(self):
        self._add_stock(self.product_a, self.wh_main, 50.0)
        req = self.env['mbt.request'].create({
            'dest_warehouse_id': self.wh_branch.id,
            'line_ids': [(0, 0, {
                'product_id': self.product_a.id,
                'product_uom_qty': 5.0,
            })],
        })
        req.action_confirm()
        self.assertEqual(req.state, 'done')
        with self.assertRaises(UserError):
            req.unlink()

    def test_09_unique_main_constraint(self):
        wh_extra = self.Warehouse.create({
            'name': 'TEST Extra',
            'code': 'TX',
            'company_id': self.company.id,
        })
        with self.assertRaises(Exception):
            wh_extra.write({'x_is_main_source': True})

    def test_10_lines_locked_in_progress(self):
        self._add_stock(self.product_a, self.wh_main, 50.0)
        req = self.env['mbt.request'].create({
            'dest_warehouse_id': self.wh_branch.id,
            'line_ids': [(0, 0, {
                'product_id': self.product_a.id,
                'product_uom_qty': 5.0,
            })],
        })
        req.action_confirm()
        with self.assertRaises(UserError):
            req.write({'line_ids': [(0, 0, {
                'product_id': self.product_a.id,
                'product_uom_qty': 9.0,
            })]})